import processing.core.*;
class Snow {
  float x;
  float y;
  float speedX;
  double speedY;
  PApplet p;
  PImage snowflake;
 


  Snow(float x, float y, float speedX, float speedY) {
    this.x = x;
    this.y = y;
    this.speedX = speedX;
    this.speedY = speedY;
  
  }

  void display() {
    snowflake = p.loadImage("image.png");
  }
  void display2() {
    p.image(snowflake, x,  y, 7, 7);
  
  }

  void move() {
    y += speedY;
  if (y >= 600) {
      y =  p.random(-1000);
    }
  if (y > 250) {
    speedY = 1.5;
  }
  if (y >450) {
    speedY = 1;
  }
  if  (y > 580) {
    y = 590;
  }
}
}      
