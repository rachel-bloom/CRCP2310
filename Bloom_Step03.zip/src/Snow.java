import processing.core.*;


    public class Snow {
        PApplet p;
        float x;
        float y;
        float speedX;
        double speedY;
        PImage snowflake;


        Snow(PApplet p, float x, float y, float speedX, double speedY) {
            this.p = p;
            this.x = x;
            this.y = y;
            this.speedX = speedX;
            this.speedY = speedY;
        }


        public void display() {
            snowflake = p.loadImage("snowflake.png");
            p.image(snowflake, x, y, 7, 7);
        }

        void move() {
            y += speedY;
            if (y >= 600) {
                y = p.random(-1000);
            }
            if (y > 250) {
                speedY = 1.5;
            }
            if (y > 450) {
                speedY = 1;
            }
            if (y > 580) {
                y = 590;
            }
        }
    }
