import processing.core.*;


    public class BloomStep03 {
        Snow[] snow;
        PApplet p;
        PImage snowflake;

        public static void main(String[] args) {
            String[] processingArgs = {"BloomStep03"};
            PApplet.main(processingArgs);
        }



        public void setup() {


            p.noStroke();
            p.size(600, 600);

            snow = new Snow[100];
            for (int i = 0; i < snow.length; i++) {
                float x = p.random(p.width);
                float y = p.random(-1000);
                float speedX = 2;
                float speedY = 2;
                snow[i] = new Snow(p, x, y, speedX, speedY);
            }
        }

        public void draw() {
            p.background(223, 230, 230);

            for (int i = 0; i < snow.length; i++) {
                snow[i].display();
                snow[i].move();
            }
        }
    }