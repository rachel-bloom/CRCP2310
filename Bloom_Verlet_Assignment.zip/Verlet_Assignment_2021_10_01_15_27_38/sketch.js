// Rachel Bloom
// Nature & Code
// Center of Creative Computation | SMU
// Fall, 2021

// Title:
// Under the Microscope 

// Description:
// Creating an organism
// based on a Verlet Box


// To Do;
// Code is altered from a project by Ira Greenberg

let bounds; // vector-+++++++++++
let verletBox;

function setup() {
    createCanvas(600, 600, WEBGL);
    // the bounds is the bigger box
    bounds = createVector(300, 300, 30); //adjusted vector size
    verletBox = new VerletBox(createVector(0, 0, 0), 80, .001, color(200, 155, 25));
    verletBox.nudge(1, createVector(10.01, 25.02, 30.03));
    let stickColor = 255
    // ignoring 3 - the node radius
    verletBox.setStyles(3, color(200, 20, 20), stickColor);
   // gif = loadImage('cells.gif')
}

function draw() {
    background(97, 58, 50); // background is red
  // resize(600,600);
  // image(gif, 0, 0);

    ambientLight(255);
    directionalLight(255, 0, 0, 0.25, 0.25, 0);
    pointLight(0, 0, 255, mouseX, mouseY, 250);

    rotateX(frameCount*PI/720);
    rotateY(frameCount*PI/720);
    drawBounds();
    
   // specularMaterial(250);
    verletBox.verlet();
    verletBox.draw();
    verletBox.boundsCollide(bounds);
}

// NOTE: Needs to be a cube 
function drawBounds() {
    noFill();
    let boundsColor = 255
    stroke(boundsColor);
    box(bounds.x, bounds.y, bounds.z)
}