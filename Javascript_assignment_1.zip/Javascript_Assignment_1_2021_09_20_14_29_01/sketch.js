// Rachel Bloom
// Nature & Code
// Center of Creative Computation | SMU
// September 19, 2021

// Title: Coy Fish Party

// Description:
// Fishtank Using:
// Array of SpringyDude
// Water gif
// Drawed lines

// Code built off of Ira Greenberg's existing code.
// Original credit goes to him


let bounds; // vector

let segmentCount = 70;

let dudes = []

// let dude1; // SpringyDude
// let dude2;
function setup() {
    createCanvas(500, 200);
    bounds = createVector(500, 200);
    
    bg = loadImage('background.jpeg');
    gif = loadImage('Water.gif') //added in a gif
  
    for (let i = 0; i < 20; ++i) {
      let random_R = Math.random() * (255);
      let random_G = Math.random() * 255
      let random_B = Math.random() * 255
      
      // Using random RGB colors for the fish
      
      let dude = makeSpringyDude(color(random_R, random_G, random_B))
      dudes.push(dude)
    }
  
  
    // let lineColor1 = color(15, 180, 255, 100)
    // let lineColor2 = color(252, 186, 3)
    // dude1 = makeSpringyDude(lineColor1)
    // dude2 = makeSpringyDude(lineColor2)
    
}


function makeSpringyDude(color) {
   let leader = new Bot(5, color, createVector(random(-100, 100), random(-100, 100)),
        createVector(random(-1.5, 1.5), random(-1.5, 1.5)));
  let followers = []
  let segmentReducer = 4.9 / segmentCount; // create wormlike body
  for (let i = 0; i < segmentCount; i++) {
        followers[i] = new Bot(5 - segmentReducer * i, color, createVector(random(-100, 100), random(-100, 100)),
            createVector(random(-1.5, 1.5), random(-1.5, 1.5)));
    }
  return new SpringyDude(leader, followers, .44, .3, 0.2);
}

// Creating array of leader and followers
// Utilizing random color and startiing points

function mousePressed() {
  gif.pause();
}

function mouseReleased() {
  gif.play();
}

// Function for restarting the gif playing in the background

function draw() {
    background(255);
    image(gif, 0, 0);
    translate(width / 2, height / 2);
    drawBounds();
  
    strokeWeight(0)
    for (let i = 0; i < dudes.length; ++i) {
      dudes[i].slither()
      dudes[i].checkBoundsCollision(bounds)
    }
//     dude1.slither();
//     dude1.checkBoundsCollision(bounds);  
    
//     //setTimeout(2000)
//     dude2.slither();
//     dude2.checkBoundsCollision(bounds);
}

function drawBounds() {
    noFill();
    stroke(0);
    
    //rect(-bounds.x / 2, -bounds.y / 2, bounds.x, bounds.y);
  strokeWeight(6) 
  stroke(50);
  line(-250, -100, -250, 100);
    stroke(50);
    line(-250, 100, 250, 100);
    stroke(50);
    line(250, 100, 250, -100);
  
  // Creation of the physical tank. 
  // The top of the box does not have a stroke
}

